# use `source` rather than `bash`
export http_proxy=http://127.0.0.1:7890
export https_proxy=http://127.0.0.1:7890
git config --global http.proxy http://127.0.0.1:7890
git config --global https.proxy https://127.0.0.1:7890
echo ' * Proxy enabled'
external_ip=`curl -s ifconfig.me`
echo ' * External IP:' $external_ip
echo ' * IP info:' `curl -s ipinfo.io/$external_ip`
