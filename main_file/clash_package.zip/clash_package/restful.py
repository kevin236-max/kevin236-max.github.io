#!/opt/conda/bin/python
# 通过restful api控制clash
# 支持查看和切换代理

import requests
import json
import sys
from termcolor import colored
import asyncio
from aiohttp import ClientSession
from copy import deepcopy

class RestfulAPI:
    def __init__(self, ip='127.0.0.1', port='9090'):
        self.url = f'http://{ip}:{port}'
    
    def traffic(self):
        response = requests.get(
            f'{self.url}/traffic',
            stream=True
        )
        def to_str(x):
            # x: int (byte/s)
            for suffix in 'BKMG':
                if x >= 1000:
                    x /= 1024
            return '%d %s/s'%(x, suffix)
        for line in response.iter_lines():
            if line:
                data = json.loads(line)
                up, down = data['up'], data['down']
                print(f'↑{to_str(up)}\t|\t↓{to_str(down)}', end='\r')
    
    def logs(self, level = 'info'):
        params = {
            'level': level
        }
        response = requests.get(
            f'{self.url}/logs',
            params=params,
            stream=True
        )
        for line in response.iter_lines():
            if line:
                data = json.loads(line)
                print(f'[{data["type"].upper()}] {data["payload"]}')
    
    def proxies(self):
        response = requests.get(
            f'{self.url}/proxies'
        )
        data = json.loads(response.text)
        return data

    def proxy_delay(self, name, timeout=1000, url='http://www.gstatic.com/generate_204'):
        # timeout(ms)
        params = {
            'timeout': timeout,
            'url': url
        }
        response = requests.get(
            f'{self.url}/proxies/{name}/delay',
            params = params
        )
        data = json.loads(response.text)
        if 'error' in data:
            raise RuntimeError(data['error'])
        if 'message' in data:
            return None
        return int(data['delay'])
    
    def proxy_delay_batch(self, names, timeout=1000, url='http://www.gstatic.com/generate_204'):
        async def fetch_proxy_delay(session, name, timeout, url):
            params = {
                'timeout': timeout,
                'url': url
            }
            try:
                async with session.get(f'{self.url}/proxies/{name}/delay', params=params) as response:
                    data = await response.json()
                    if 'error' in data:
                        raise RuntimeError(data['error'])
                    if 'message' in data:
                        return None
                    return int(data['delay'])
            except Exception as e:
                return str(e)
        async def _proxy_delay(names, timeout, url):
            async with ClientSession() as session:
                tasks = [fetch_proxy_delay(session, name, timeout, url) for name in names]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                return results
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        results = loop.run_until_complete(_proxy_delay(names, timeout, url))
        return results
    
    def set_proxy(self, sname, pname):
        # sname: selector name
        # pname: proxy name
        body = {
            'name': pname
        }
        response = requests.put(
            f'{self.url}/proxies/{sname}',
            json = body
        )
        if len(response.text.strip()) == 0:
            return
        data = json.loads(response.text)
        if 'error' in data:
            raise RuntimeError(data['error'])
        if 'message' in data:
            raise RuntimeError(data['message'])
    
    def run(self, *args):
        # args: sys.argv[1:]
        cmd = args[0]
        if cmd == 'traffic':
            self.traffic()
        elif cmd == 'log':
            if len(args) >= 2:
                level = args[1]
                self.logs(level)
            else:
                self.logs()
        elif cmd == 'proxy':
            data = self.proxies()
            selector_list = dict()
            for k, v in data['proxies'].items():
                if k == 'GLOBAL':
                    continue
                if v['type'] == 'Selector' and len(v['all']) > 0:
                    selector_list[k] = v
            def user_select(lst):
                # lst: list<str>
                # comments: list<str>
                if len(lst) == 0:
                    raise RuntimeError('Unexpected empty list!')
                if len(lst) == 1:
                    return 0, lst[0]
                for idx, item in enumerate(lst):
                    print(f'{idx+1}.\t{item}')
                while True:
                    try:
                        inp = input('> ')
                        inp = int(inp)-1
                        break
                    except Exception as e:
                        print(e)
                return inp, lst[inp]
            
            _, sname = user_select(list(selector_list.keys()))

            # 在选项中打印更详细的信息
            pname_list = selector_list[sname]['all']
            now_selected = selector_list[sname]['now']

            displayed_text = deepcopy(pname_list)
            print(' * testing delay...')
            delay_list = self.proxy_delay_batch(pname_list)
            for idx, name in enumerate(pname_list):
                if name == now_selected:
                    displayed_text[idx] = colored(name, 'black', 'on_white')

                # delay test
                delay = delay_list[idx]
                if delay is None:
                    displayed_text[idx] += '\t%s'%colored('error', 'red')
                elif delay <= 300:
                    displayed_text[idx] += '\t%s'%colored(f'{delay}ms', 'green')
                else:
                    displayed_text[idx] += '\t%s'%colored(f'{delay}ms', 'yellow')

                # resolve reference
                if name in data['proxies'] and 'now' in data['proxies'][name]:
                    displayed_text[idx] += '\t(%s)'%data['proxies'][name]['now']

            p_idx, p_info = user_select(displayed_text)
            pname = selector_list[sname]['all'][p_idx]
            self.set_proxy(sname, pname)
            print(f' * Successfully set proxy to {sname}/{p_info}')
        else:
            raise ValueError(f'Invalid command `{cmd}`')

if __name__ == '__main__':
    try:
        if len(sys.argv) == 1:
            print('available command: traffic | log | proxy')
        else:
            RestfulAPI().run(*sys.argv[1:])
    except KeyboardInterrupt:
        print('\n * exit')
