mkdir ~/clash
mkdir -p ~/.config/clash
cp ./* ~/clash
cp ./config/* ~/.config/clash
